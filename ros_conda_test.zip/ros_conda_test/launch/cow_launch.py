from launch import LaunchDescription
from launch.actions import ExecuteProcess
import os

def generate_launch_description():
    conda_env_path = "/home/coolze/anaconda3/envs/robotics_env"
    conda_python = f"{conda_env_path}/bin/python"

    return LaunchDescription([
        ExecuteProcess(
            cmd=[conda_python, '-m', 'ros_conda_test.cow_node'],
            name='cow_node',
            output='screen',
            shell=False,
        )
    ])
