import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from cowpy import cow


class CowPublisher(Node):
    def __init__(self):
        super().__init__('cow_talker')
        self.publisher_ = self.create_publisher(String, 'cow_topic', 10)
        timer_period = 2.0  # 每2秒发布一次
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.cow = cow.Cowacter()
        self.get_logger().info('CowPublisher节点启动成功')

    def timer_callback(self):
        message = self.cow.milk('Hello from cowpy!')
        msg = String()
        msg.data = message
        self.publisher_.publish(msg)
        self.get_logger().info(f'发布消息:\n{message}')


def main(args=None):
    rclpy.init(args=args)
    node = CowPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('节点被中断')
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
